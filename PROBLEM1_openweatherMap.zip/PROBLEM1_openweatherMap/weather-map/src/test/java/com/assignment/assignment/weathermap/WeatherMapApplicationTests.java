package com.assignment.assignment.weathermap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class WeatherMapApplicationTests {

	//@Test
	void contextLoads() {
	}

}
